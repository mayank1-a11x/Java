package apack;

public class A {
    int defaultVar = 10;
    protected int protectedVar = 20;
    private int privateVar = 30;
    public int publicVar = 40;
}
