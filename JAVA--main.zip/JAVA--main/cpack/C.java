package cpack;

import apack.A;

public class C {
    public void display() {
        A a = new A();

        // System.out.println("Default: " + a.defaultVar);
        // System.out.println("Protected: " + a.protectedVar);
        // System.out.println("Private: " + privateVar);
        System.out.println("Public: " + a.publicVar);
    }
}
